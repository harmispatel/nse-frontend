export const BASE_URL =
  "https://www.nseindia.com/api/option-chain-indices?symbol=";

export const BANKNIFTY_API = `${BASE_URL}BANKNIFTY`;

export const NIFTY_API = `${BASE_URL}NIFTY`;

export const PCR_STOCK_URL = `https://www.nseindia.com/api/option-chain-equities?symbol=`;
