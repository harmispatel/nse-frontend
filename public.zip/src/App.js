import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import BankNifty from "./pages/BankNifty";
import Home from "./pages/Home";
import Nifty from "./pages/Nifty";
import Login from "./admin/Login";
import LiveNse from "./admin/LiveNse";
import DemoTable from "./admin/DemoTable";
import HistoryData from "./admin/HistoryNse";
import PrivateRoutes from "./services/PrivateRoutes";
import SettingsNse from "./admin/SettingsNse";
import AccountDetails from "./admin/AccountDetails";
import PcrValues from "./pages/PcrValues";
// import Nsetable from "./nse/nsetable";
import PcrChart from "./pages/PcrChart";
import Item from "./pages/item";
// import Model from "./pages/Model";
import ChangePasswordForm from "./admin/forgetpassword";
import Logout from "./pages/Logout";
import { ToastContainer } from "react-toastify";
import AdminBankNifty from "./pages/AdminBankNifty";

function App() {
  return (
    <div className="App">
      <div>
        <Router>
          <Routes>
            <Route element={<PrivateRoutes />}>
              <Route exact path="/" element={<Home />} />
              <Route path="/item" element={<Item />} />
              <Route path="/bank-nifty" element={<BankNifty />} />
              <Route path="/admin-banknifty" element={<AdminBankNifty />} />
              <Route path="/nifty-50" element={<Nifty />} />
              <Route path="/pcr" element={<PcrValues />} />
              {/* <Route path="/demo" element={<Nsetable />} /> */}
              <Route path="/pcrchart/:name" element={<PcrChart />} />
              <Route path="/logout" element={<Logout />} />
            </Route>
            
            <Route element={<PrivateRoutes />}>
              <Route path="/admin-live" element={<LiveNse />} />
              <Route path="/demotable" element={<DemoTable />} />
              <Route path="/admin-history" element={<HistoryData />} />
              <Route path="/admin-settings" element={<SettingsNse />} />
              <Route path="/admin-accountdetails" element={<AccountDetails />} />
              <Route path="/reset-password" element={<ChangePasswordForm />} />
            </Route>
            <Route path="/login" element={<Login />} />
          </Routes>
        </Router>
        <ToastContainer autoClose={2000}  />
      </div>
    </div>
  );
}

export default App;
