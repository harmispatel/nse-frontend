import React, { useEffect } from 'react'
import { LOGOUT } from "../api/LocalApi";
import { useNavigate } from "react-router-dom";
import axios from 'axios';

export default async function Logout() {
    const navigate = useNavigate();

    useEffect( async () => {
        
        
          await axios({
            method: "post",
            url: LOGOUT,
            headers:{
                Authorization:"Token "+localStorage.getItem("token")
            }
          }).then((response) => {
            console.log(response.data);
            localStorage.removeItem("token")
            navigate("/login");
          });
        
      }, []);
      
  return (
    <div></div>
  )
}
