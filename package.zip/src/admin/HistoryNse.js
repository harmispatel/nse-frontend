import React from "react";
import { Layout, Table, Tag, Breadcrumb, Switch } from "antd";
import NseService from "../services/NseService";
import { useEffect, useState } from "react";
import moment from "moment/moment";
import Sidebar from "./Sidebar";
import axios from "axios";
import { LOCAL_STOCK_API_URL } from "../api/LocalApi";

const { Header } = Layout;
const { Content } = Layout;

const HistoryData = () => {

const columns = [
    {
      title: "Id",
      key: "index",
      render: (text, record, index) => index + 1,
    },
    {
      title: "Base Strike Price",
      dataIndex: "base_strike_price",
      key: "base_strike_price",
      render: (text, record) => { 
        return text ?? '-'
      }
    },
    {
      title: "Live Strike Price",
      dataIndex: "live_Strike_price",
      key: "live_Strike_price",
      render: (text, record) => { 
        return text ?? '-'
      }
    },
    {
      title: "Buy Price",
      dataIndex: "buy_price",
      key: "buy_price",
      render: (text, record) => {
        return <Tag color={"processing"}>{text}</Tag>;
      },
    },
    {
      title: "Sell Price",
      dataIndex: "sell_price",
      key: "sell_price",
    },
    {
      title: "Stop Loseprice",
      dataIndex: "stop_loseprice",
      key: "stop_loseprice",
    },
    // {
    //   title: "Live Brid Price",
    //   dataIndex: "live_brid_price",
    //   key: "live_brid_price",
    // },
    {
      title: "Exit Price",
      dataIndex: "exit_price",
      key: "exit_price",
      render: (text, record) => {
        return <Tag color={text !== null ? "error" : ""}>{text}</Tag>;
      },
    },
    {
      title: "Buy Time",
      dataIndex: "buy_time",
      key: "buy_time",

      sorter: (a, b) => moment(a.buy_time).unix() - moment(b.buy_time).unix(),

      render: (text, record) => {
        return moment(text).format("DD/MM/YYYY HH:mm:ss");
      },
    },
    {
      title: "Sell Time",
      dataIndex: "sell_buy_time",
      key: "sell_buy_time",

      sorter: (a, b) =>
        moment(a.sell_buy_time).unix() - moment(b.sell_buy_time).unix(),
      render: (text, record) => {
        return moment(text).format("DD/MM/YYYY HH:mm:ss");
      },
    },
    {
      title: "Option",
      dataIndex: "percentage",
      key: "percentage",
      render: (text, record) => {
        if (text.option === 'STOCK CE' || text.option === 'STOCK PE' || text.option === 'STOCK PCR CE' || text.option === 'STOCK PCR PE') {
          return record.stock_name;
        }
        return text.option;
      },
      filters: [
        {
          text: "BANKNIFTY CE",
          value: "BANKNIFTY CE",
        },
        {
          text: "NIFTY CE",
          value: "NIFTY CE",
        },
        {
          text: "NIFTY PE",
          value: "NIFTY PE",
        },
        {
          text: "BANKNIFTY PE",
          value: "BANKNIFTY PE",
        },
        {
          text: "STOCK CE",
          value: "STOCK CE",
        },
      ],
      onFilter: (value, record) => {
        return record.percentage.option === value;
      },
    },
    {
      title: "Final Status",
      dataIndex: "final_status",
      key: "final_status",
      filters: [
        {
          text: "PROFIT",
          value: "PROFIT",
        },
        {
          text: "LOSS",
          value: "LOSS",
        },
      ],
      onFilter: (value, record) => {
        console.log(value);
        return record.final_status === value;
      },
      render: (text, record) => {
        return (
          <Tag color={text === "PROFIT" ? "success" : "error"}>{text}</Tag>
        );
      },
    },
  ];

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ current: 1, total: 0  });
  const [localapi, setLocalApi] = useState(localStorage.getItem("Local"));
  
  const setLocal = () => {
    if (localapi === 'true') {
      localStorage.setItem("Local", 'false');
      setLocalApi('false')
    }else{ 
      localStorage.setItem("Local", 'true');
      setLocalApi('true')
    }
  };

  useEffect(() => {
    document.title = "History Data";
    loadNse(pagination.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pagination.current, localapi]);


  const loadNse = (page) => {
    if (localapi === 'true') {
        axios.get(LOCAL_STOCK_API_URL + '/stocks?page=' + page).then((response) => { 
          let buyData = response?.data?.data?.filter((item) => {
            return item.status === "SELL"
            });
          setLoading(false);
          setData(buyData);
          setPagination({
            ...pagination,
            total: response.data.count, 
            current: page,   
          });
        })
      }else{ 
        NseService.getNse(page).then((response) => {
          let buyData = response?.data?.data?.filter((item) => {
            return item.status === "SELL"
            });
            setLoading(false);
            setData(buyData);
            setPagination({
              ...pagination,
              total: response.data.count, 
              current: page,   
            });
        });
    }
  };

  const handleTableChange = (pagination) => {
    setPagination(pagination);
  };

  return (
    <>
      <Layout>
        <Header className="head-main">
          <div className="logo" />
        </Header>

        <Layout>
          <Sidebar />

          <Layout className="site-layout-background" style={{ margin: "24px 16px 0" }} >

            <Breadcrumb style={{ margin: "16px 30px" }}>
              <Breadcrumb.Item>Admin</Breadcrumb.Item>
              <Breadcrumb.Item>History{localapi === 'true' && ' (local)'}</Breadcrumb.Item>
            </Breadcrumb>

            <div>
              <Switch style={{float: 'right', marginRight: "28px"}}
                onChange={setLocal}
                checked={localapi === 'true' ? true : false}
                />
            </div>

            <Content
              
              style={{
                padding: "14px 24px",
                margin: 0,
                minHeight: 280,
                }}
            >

                <Table
                  rowKey={(record) => record.id}
                  columns={columns}
                  dataSource={data}
                  loading={loading}
                  pagination={{
                    ...pagination,
                    showSizeChanger: false, 
                  }}
                  onChange={handleTableChange}
                />
  
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </>
  );
};

export default HistoryData;
